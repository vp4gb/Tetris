package edu.umkc.varun.game;

public interface IEngine {
public void callGame();
}
