package edu.umkc.varun.engine;

public interface IPlayer {
	
	public void setCyclesPerSecond(float cyclesPerSecond);

	public void Clock2(float cyclesPerSecond) ;

}
