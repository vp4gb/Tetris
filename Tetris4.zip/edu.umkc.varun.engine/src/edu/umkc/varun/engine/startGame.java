package edu.umkc.varun.engine;
import edu.umkc.varun.game.IEngine;
import org.psnbtech.*;

public class startGame implements IEngine {

	public startGame() {
		
	}
		// TODO Auto-generated constructor stub
		public void callGame() {
			// TODO Auto-generated method stub
			final Tetris tetris = new Tetris();
			Thread t1 = new Thread(){
			    public void run(){
			    	
			    	tetris.startGame();
			    }}; 
				    t1.start();
				   
		}
	}





