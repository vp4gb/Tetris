package edu.umkc.wow;

import edu.umkc.wow.Control.ControlArch;
import edu.umkc.wow.Pl1.Pl1Arch;

public interface IGame {
	
	public void callgame() ;

}
